

# Introduction to Subqueries 

create database inclass5;
use inclass5;
# Dataset used: titanic_ds.csv

----------------------------------------------------------------------------------------------

## 1. Introduction to Subqueries in MySQL

### Overview
-- A subquery is a query nested within another SQL query, also known as an inner query. 

### Syntax

SELECT column_name(s)
FROM table_name
WHERE column_name operator
    (SELECT column_name FROM table_name WHERE condition);

----------------------------------------------------------------------------------------------



## 1.1. Single-row Subqueries

### Definition
-- A single-row subquery is a subquery that returns only one row of results. 
-- It is typically used with operators that expect a single value, such as `=`, `<`, `>`, `<=`, or `>=`.


### Example

-- Display the first_name, last_name, passenger_no , fare of the passenger who paid second highest fare. 

select first_name, last_name, passenger_no, max(fare) second_highest_fare from titanic_ds where fare < (select max(fare) from titanic_ds) ;



### Interview FAQ

-- Write a query to find the product with the lowest price in the `products` table.

-- Find the name of employee with second highest salary.


----------------------------------------------------------------------------------------------

## 1.2. Multiple-row Subqueries

### Definition
-- A multiple-row subquery returns more than one row of results.
-- Operators used with multiple-row subqueries include `IN`, `ANY`, and `ALL`.

### Example

-- Display first_name,embark_town where deck is equals to the deck of embark town ends with word 'town'.
-- Use `IN` when you want to match any value within a list of values.
-- `ANY` can be used to compare each value in the list returned by the subquery with a condition.


-- Find all employees who work in departments located in New York.
-- Table employee : employee_id, employee_name, department_id
-- Table department : department_id , location




----------------------------------------------------------------------------------------------



## 1.3. Multiple-column Subqueries

### Definition
-- A multiple-column subquery retrieves multiple columns 
-- It is often used when you need to compare a combination of columns rather than just one.

### Example
-- Find passengers first_name, age, class details with the same age and class as the youngest male passenger.

SELECT first_name, age, pclass
FROM titanic_ds
WHERE (age, pclass) IN (
    SELECT MIN(age), pclass
    FROM titanic_ds
    WHERE sex = 'male'
);

----------------------------------------------------------------------------------------------

## 1.4. Correlated Subqueries

### Definition
A correlated subquery is a subquery that refers to a column from the outer query. 
This means the subquery is executed once for each row processed by the outer query.

### Example

-- Find passenger's first_name, pclass, fare who paid a fare above the average fare for their class.

SELECT first_name, pclass, fare
FROM titanic_ds AS t1
WHERE fare > (
    SELECT AVG(fare)
    FROM titanic_ds AS t2
    WHERE t1.pclass = t2.pclass
);


----------------------------------------------------------------------------------------------



############################################ VIEWS ############################################


What is a View?
A view is a virtual table based on a SELECT query. 

-- It allows us to:
-- Save complex queries for easy reuse.
-- Simplify access to frequently queried data.
-- Improve security by restricting access to specific columns or rows.

----------------------------------------------------------------------------------------------

## Simple View

Create a view which contains data for passengers in the first class.

CREATE VIEW first_class_passengers AS
SELECT first_name, Sex, Age, Survived
FROM titanic_ds
WHERE Pclass = 1;

drop view first_class_passengers;



-- Retrieve all first-class passengers who survived (survived = 1).

SELECT * FROM first_class_passengers WHERE Survived = 1;


----------------------------------------------------------------------------------------------


## Materialized Views

-- Physical copies of the data that store query results as a table. 
-- Data is periodically refreshed to stay up-to-date.
-- Faster query performance because data is precomputed.
-- Ideal for large datasets where real-time calculations are costly.


-- Example:
CREATE MATERIALIZED VIEW avg_fare_per_class AS
SELECT Pclass, AVG(Fare) AS AvgFare
FROM titanic_ds
GROUP BY Pclass;


-- Some SQL databases, like Oracle, PostgreSQL, and Snowflake, support materialized views, 
-- while others, like MySQL, SQLite, MSSQL server do not but offer alternatives such as scheduled updates.

